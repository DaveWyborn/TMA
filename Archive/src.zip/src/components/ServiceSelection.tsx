"use client";

import { useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import dynamic from "next/dynamic";

// Import service descriptions
import analyticsDescription from "./services/analytics";
import visualisationDescription from "./services/visualisation";
import consentDescription from "./services/consent";

// ✅ Dynamically load DOMPurify only in the browser to prevent SSR issues
let DOMPurify: any = null;
if (typeof window !== "undefined") {
  import("dompurify").then((mod) => {
    DOMPurify = mod.default || mod;
  });
}

// ✅ Service Data
const services = [
  { id: "analytics", title: "Website Analytics", description: analyticsDescription, icon: "/icons/analytics.svg" },
  { id: "visualisation", title: "Data Visualisation", description: visualisationDescription, icon: "/icons/visualisation.svg" },
  { id: "consent", title: "Consent Management", description: consentDescription, icon: "/icons/consent.svg" },
];

const ServiceSelection = () => {
  const [selectedService, setSelectedService] = useState(services[0].id);

  return (
    <section id="services" className="w-full h-screen flex flex-col items-center justify-center bg-white scroll-snap-align-start pt-24 md:pt-0 text-gray-800">

      <h2 className="text-3xl font-semibold text-[#6C04DC] mb-6 text-center">Our Services</h2>

      {/* Service Selection Buttons */}
      <div className="flex flex-col md:flex-row justify-center gap-6 mb-8 w-full px-4">
        {services.map((service) => (
          <button
            key={service.id}
            className={`flex items-center md:flex-col px-4 md:px-6 pb-2 border-b-2 transition-all duration-300 transform w-full md:w-auto
              ${selectedService === service.id ? "border-[#6C04DC] text-[#6C04DC] scale-105 font-semibold" : "border-gray-400 text-gray-700"}
              hover:border-[#AD72F9] hover:text-[#AD72F9] hover:scale-110`}
            onClick={() => setSelectedService(service.id)}
          >
            <Image
              src={service.icon}
              alt={service.title}
              width={40}
              height={40}
              className="mr-4 md:mr-0 md:mb-2 transition-transform duration-300"
            />
            <span className="text-lg text-left md:text-center">{service.title}</span>
          </button>
        ))}
      </div>

      {/* Selected Service Description - HTML SAFE */}
      <div className="max-w-2xl mx-auto text-left px-4 md:px-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedService}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <div
              className="text-lg text-gray-700 leading-relaxed"
              dangerouslySetInnerHTML={{
                __html: DOMPurify && typeof DOMPurify.sanitize === "function"
                  ? DOMPurify.sanitize(services.find((service) => service.id === selectedService)?.description ?? "",
                      { ALLOWED_TAGS: ["h3", "p", "strong", "ul", "li", "span", "br"] })
                  : "",
              }}
            />
            <a 
              href="#contact"
              className="inline-block mt-4 px-6 py-2 text-white bg-[#6C04DC] border-2 border-[#6C04DC] rounded-full hover:bg-[#AD72F9] hover:border-[#AD72F9] transition"
            >
              Get Started
            </a>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
};

// ✅ Ensure component is client-side only
export default dynamic(() => Promise.resolve(ServiceSelection), { ssr: false });
