import HeroSection from "@/components/HeroSection";
import ServiceSelection from "@/components/ServiceSelection";
import NavBar from "@/components/NavBar";
import ContactForm from "@/components/ContactForm";
import Testimonials from "@/components/Testimonials";

export default function Home() {
  return (
    <main className="h-screen overflow-y-auto scroll-snap-type-y-mandatory">
      <NavBar />
      <HeroSection />

      <section className="relative w-full h-screen flex items-center justify-center text-center">
        <ServiceSelection />
      </section>

      <section id="testimonials" className="w-full h-screen flex flex-col items-center justify-center bg-gray-200 scroll-snap-align-start">
        <Testimonials />
      </section>

      <section id="contact" className="w-full h-screen flex flex-col items-center justify-center bg-gray-300 scroll-snap-align-start">
        <ContactForm />
      </section>
    </main>
  );
}
