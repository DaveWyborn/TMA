const testimonials = [
  {
    quote: "Tailor Made Analytics helped us unlock insights we never knew existed. Highly recommended!",
    author: "Sarah Thompson, Marketing Director",
  },
  {
    quote: "Their expertise in GA4 and Looker Studio transformed our reporting. Couldn't be happier!",
    author: "James Wilson, E-commerce Manager",
  },
  {
    quote: "Professional, efficient, and extremely knowledgeable in data analytics!",
    author: "Emily Carter, CEO of DataTech Solutions",
  },
];

export default testimonials;
